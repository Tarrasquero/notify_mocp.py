#!/usr/bin/env python
# -*- coding: utf-8 -*-
import notify2
import os
import requests
from re import sub
from PIL import Image
from commands import getoutput
from sys import argv
from cgi import escape
from cPickle import dump
from cPickle import load
import mocrepla

notify2.init("mocp")
__autor__ = "Jorge"


class Cuerpo():
    def Load(self):
        self.file_dump = '/tmp/pymocp.id'
        self.n = None
        try:
            self.n = load(open(self.file_dump, mode="rb"))
        except IOError:
            self.n = notify2.Notification('')

    def Dump(self):
        objeto = os.path.abspath(os.path.join(
            __file__, os.pardir, 'icon-moc.png'))
        try:
            self.n.update(self.sumario, self.datos, self.png)
            self.n.show()
            self.n = dump(self.n, open(self.file_dump, mode='wb'))
        except AttributeError:
            self.n.update(self.sumario, self.datos, objeto)
            self.n.show()
            self.n = dump(self.n, open(self.file_dump, mode='wb'))


class Notify(Cuerpo):
    def Imagen(self):
        play = getoutput('mocp -Q %state')
        if (play != 'PLAY'):
            self.datos = "Mocp no está funcionando"
            self.sumario = "STOP"
            return (self.sumario, self.datos)
        try:
            self.artista = argv[1]
            self.cancion = argv[2]
            self.album = argv[3]
            self.fil = argv[4]
        except IndexError:
            self.artista = getoutput('mocp -Q %artist')
            self.cancion = getoutput('mocp -Q %song')
            self.album = getoutput('mocp -Q %album')
            self.fil = getoutput('mocp -Q %file')
        if not self.cancion:
            filename = os.path.splitext(self.fil)[0]
            filename = os.path.basename(filename)
            f = filename.split(' - ')
            self.artista = f[0]
            self.cancion = f[1]
            al = self.fil.split('/')
            self.album = al[4]
        self.sumario = ''
        self.datos = ("<b>Artista:  </b>" + "<b>%s</b>" %
                      escape(self.artista) + '\n' +
                      "<b>Cancion:  </b>" + "<i>%s</i>" %
                      escape(self.cancion) + '\n' +
                      "<b>Album:  </b>" + "<i>%s</i>" %
                      escape(self.album))
        if '(' in self.artista:
            self.artista = self.artista.split(' (')
            self.artista = self.artista[0]
        elif '[' in self.artista:
            self.artista = self.artista.split(' [')
            self.artista = self.artista[0]
        if '(' in self.album:
            self.album = self.album.split(' (')
            self.album = self.album[0]
        elif '[' in self.album:
            self.album = self.album.split(' [')
            self.album = self.album[0]
        _path = self.fil.rfind('/')
        if _path != -1:
            _path = self.fil[:_path + 1]
        lstDir = os.walk(_path)
        self.control = 0
        for root, dirs, files in lstDir:
            root1 = root.rstrip('/')
            root1 = root1.rfind('/')
            if root1 != -1:
                _path = root[:root1 + 1]
                for fichero in os.listdir(_path):
                    corte = fichero.rfind('.')
                    nombreFichero = fichero[:corte]
                    extension = fichero[corte:]
                    self.img = '{0}{1}'.format(_path, fichero)
                    self.width = 100
                    self.height = 100
                    if extension == '.jpg' or '.png':
                        if extension == '.jpg':
                            self.imagen = Image.open(self.img).resize((self.width, self.height), Image.ANTIALIAS)
                            self.imagen.save(_path + nombreFichero +'.png', 'PNG')
                            self.png = '{0}{1}{2}'.format(_path, nombreFichero, '.png')
                            os.remove(self.img)
                            self.control = 1
                            return self.png
                        if extension == '.png':
                            self.imagen = Image.open(self.img).resize((
                                    self.width, self.height), Image.ANTIALIAS)
                            self.imagen.save(_path + nombreFichero + '.png', 'PNG')
                            self.png = '{0}{1}{2}'.format(_path, nombreFichero, '.png')
                            self.control = 1
                            return self.png
                    else:
                        pass
        if self.control == 0:
            _path = self.fil.rfind('/')
            if _path != -1:
                _path = self.fil[:_path + 1]
            lstDir = os.walk(_path)
            for root, dirs, files in lstDir:
                for fichero in files:
                    (nombreFichero, extension) = os.path.splitext(fichero)
                    self.img = '{0}{1}'.format(_path, fichero)
                    self.width = 100
                    self.height = 100
                    if extension == 'jpg' or 'png':
                        pass
                    if extension == '.jpg':
                        try:
                            self.imagen = Image.open(self.img).resize((self.width, self.height), Image.ANTIALIAS)
                        except IOError:
                            break
                        self.imagen.save(_path + nombreFichero +'.png', 'PNG')
                        self.png = '{0}{1}{2}'.format(_path, nombreFichero, '.png')
                        os.remove(self.img)
                        self.control = 1
                        return self.png
                    if extension == '.png':
                        self.imagen = Image.open(self.img).resize((
                                self.width, self.height), Image.ANTIALIAS)
                        self.imagen.save(_path + nombreFichero + '.png', 'PNG')
                        self.png = '{0}{1}{2}'.format(_path, nombreFichero, '.png')
                        self.control = 1
                        return self.png
        if self.control == 0:
            try:
                cover = mocrepla.descargar_img(self.artista, self.album)
                jpg = requests.get(cover).content
                self.img = '{0}{1}'.format(
                _path, 'Front.jpg')
                self.png = (_path + 'Front' + '.png')
                with open(self.img, 'wb') as handler:
                    handler.write(jpg)
                self.imagen = Image.open(self.img)
                self.imge = self.imagen.resize((self.width, self.height), Image.ANTIALIAS)
                self.imge.save(self.png, 'PNG')
                os.remove(self.img)
            except AttributeError:
                self.png = '/usr/share/icons/icon-moc.png'
                return (self.artista, self.cancion, self.png)
            

if __name__ == "__main__":
    MiNotify = Notify()
    MiNotify.Load()
    MiNotify.Imagen()
    MiNotify.Dump()
