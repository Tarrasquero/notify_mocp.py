#! /usr/bin/env python
# -*- coding: utf-8 -*-
import requests
from bs4 import BeautifulSoup

cookies = dict(cookies_are='AMCV_10D31225525FF5790A490D4D%40AdobeOrg')
s = requests.Session()

def descargar_img(cantante, disco):
    disco = disco.replace("'", "")
    buscar = (cantante + ' ' + disco)
    buscar = buscar.replace(' ', '+')
    urlbase = "https://www.last.fm/es/search?q=%s" % buscar
    requ = s.get(urlbase, cookies=cookies)
    soup = BeautifulSoup(requ.text, "html.parser")
    find = soup.find('link', {'data-replaceable-head-tag': ''})['href']
    requ1 = s.get(find, cookies=cookies)
    soup1 = BeautifulSoup(requ1.text, 'html.parser')
    find2 = soup1.find('div', {'class': ' grid-items-cover-image-image '}).img['src']
    return find2
